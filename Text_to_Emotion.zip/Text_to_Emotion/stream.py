import streamlit as st
import pickle
import re
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import time

# ── Page config (MUST be first Streamlit call) ──────────────────────────────
st.set_page_config(
    page_title="Text to Emotion",
    page_icon="🎭",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Load Models (cached) ─────────────────────────────────────────────────────
@st.cache_resource
def load_models():
    with open("Backend/notebooks/best_model.pkl", "rb") as f:
        model = pickle.load(f)
    with open("Backend/notebooks/vectorizer.pkl", "rb") as f:
        vectorizer = pickle.load(f)
    with open("Backend/notebooks/label_encoder.pkl", "rb") as f:
        encoder = pickle.load(f)
    return model, vectorizer, encoder

model, vectorizer, label_encoder = load_models()

# ── Text Preprocessing ───────────────────────────────────────────────────────
def clean_text(text: str) -> str:
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", "", text)
    text = re.sub(r"[^a-z\s]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

# ── Prediction Function ──────────────────────────────────────────────────────
def predict_emotion(text: str) -> dict:
    cleaned = clean_text(text)
    X = vectorizer.transform([cleaned])
    probs = model.predict_proba(X)[0]
    classes = label_encoder.classes_
    return {cls: float(prob) for cls, prob in zip(classes, probs)}

# ── Emotion Metadata — all 11 real classes ───────────────────────────────────
EMOTION_META = {
    "anger":      {"emoji": "😠", "color": "#E74C3C"},
    "empty":      {"emoji": "😶", "color": "#95A5A6"},
    "enthusiasm": {"emoji": "🤩", "color": "#F39C12"},
    "fun":        {"emoji": "😂", "color": "#1ABC9C"},
    "happiness":  {"emoji": "😄", "color": "#FFD700"},
    "hate":       {"emoji": "😤", "color": "#C0392B"},
    "love":       {"emoji": "❤️",  "color": "#E91E63"},
    "neutral":    {"emoji": "😐", "color": "#7F8C8D"},
    "relief":     {"emoji": "😌", "color": "#27AE60"},
    "sadness":    {"emoji": "😢", "color": "#4A90D9"},
    "surprise":   {"emoji": "😲", "color": "#9B59B6"},
}

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .stApp { background-color: #0f0f1a; }
    section[data-testid="stSidebar"] { background-color: #13132b; }

    .title-section { text-align: center; padding: 2rem 0 1rem 0; }
    .main-title {
        font-size: 3rem;
        font-weight: 800;
        background: linear-gradient(135deg, #667eea, #764ba2, #f093fb);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    .subtitle { color: #a0aec0; font-size: 1.1rem; margin-top: -0.5rem; }

    .emotion-card {
        background: linear-gradient(135deg, #1a1a2e, #16213e);
        border-radius: 16px;
        padding: 1.5rem;
        text-align: center;
        border: 1px solid #2d2d5e;
        margin-bottom: 1rem;
    }
    .dominant-emotion { font-size: 4rem; margin-bottom: 0.3rem; }
    .emotion-label {
        font-size: 1.8rem;
        font-weight: 700;
        color: #ffffff;
        text-transform: capitalize;
    }
    .confidence-text { color: #a0aec0; font-size: 1rem; margin-top: 0.3rem; }

    .stTextArea textarea {
        background-color: #1a1a2e !important;
        color: #ffffff !important;
        border: 2px solid #2d2d5e !important;
        border-radius: 12px !important;
        font-size: 1rem !important;
    }
    .stTextArea textarea:focus {
        border-color: #667eea !important;
        box-shadow: 0 0 0 3px rgba(102,126,234,0.2) !important;
    }

    .stButton > button {
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: white;
        border: none;
        border-radius: 12px;
        padding: 0.7rem 2rem;
        font-size: 1.1rem;
        font-weight: 600;
        width: 100%;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
    }

    .history-item {
        background: #1a1a2e;
        border-left: 4px solid #667eea;
        border-radius: 8px;
        padding: 0.8rem 1rem;
        margin-bottom: 0.6rem;
        color: #e2e8f0;
        font-size: 0.9rem;
    }

    hr { border-color: #2a2a5e !important; }
</style>
""", unsafe_allow_html=True)

# ── Session State ─────────────────────────────────────────────────────────────
if "history" not in st.session_state:
    st.session_state.history = []
if "total_analyzed" not in st.session_state:
    st.session_state.total_analyzed = 0

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🎭 Text to Emotion")
    st.caption("Logistic Regression · TF-IDF · 11 Emotions")
    st.markdown("---")

    st.markdown("### ⚙️ Settings")
    show_all_emotions = st.toggle("Show all emotion scores", value=True)
    chart_type = st.selectbox(
        "Chart type",
        ["Bar Chart", "Radar Chart", "Pie Chart"],
        index=0
    )
    top_n = st.slider("Top N emotions to display", 3, 11, 7)
    st.markdown("---")

    st.markdown("### 📊 Session Stats")
    st.metric("Texts Analyzed", st.session_state.total_analyzed)

    if st.session_state.history:
        emotions_seen = [h["dominant"] for h in st.session_state.history]
        most_common = max(set(emotions_seen), key=emotions_seen.count)
        meta = EMOTION_META.get(most_common, {"emoji": "❓"})
        st.metric("Most Common Emotion", f"{meta['emoji']} {most_common.capitalize()}")

    st.markdown("---")
    if st.button("🗑️ Clear History"):
        st.session_state.history = []
        st.session_state.total_analyzed = 0
        st.rerun()

    st.markdown("---")
    st.markdown(
        "<p style='color:#555;font-size:0.8rem;text-align:center;'>"
        "Text_to_Emotion v1.0<br>Built with Streamlit<br>"
        "Model: Logistic Regression<br>"
        "Classes: 11 Emotions</p>",
        unsafe_allow_html=True
    )

# ── Main Page ─────────────────────────────────────────────────────────────────
st.markdown("""
<div class='title-section'>
    <div class='main-title'>🎭 Text to Emotion</div>
    <div class='subtitle'>Detect emotions from text using NLP & Machine Learning</div>
</div>
""", unsafe_allow_html=True)
st.markdown("---")

# ── Input Section ─────────────────────────────────────────────────────────────
col1, col2, col3 = st.columns([1, 3, 1])
with col2:
    user_input = st.text_area(
        "✍️ Enter your text below",
        placeholder="Type something like: 'I just got promoted and I'm so excited!'",
        height=140,
        label_visibility="visible"
    )
    col_btn1, col_btn2, col_btn3 = st.columns([1, 2, 1])
    with col_btn2:
        analyze_btn = st.button("🔍 Analyze Emotion", use_container_width=True)

# ── Example Texts — covers all 11 emotions ───────────────────────────────────
st.markdown("#### 💡 Try an example:")
ex_cols = st.columns(4)
examples = [
    ("😄 Happiness",   "I just got the job offer! This is the best day of my life!"),
    ("😢 Sadness",     "I miss my old friends so much. Everything feels empty lately."),
    ("😠 Anger",       "I can't believe they lied to me. This is absolutely unacceptable!"),
    ("🤩 Enthusiasm",  "I am so pumped and ready to take on this challenge, let's go!"),
]
for i, (label, text) in enumerate(examples):
    with ex_cols[i]:
        if st.button(label, key=f"ex_{i}", use_container_width=True):
            user_input = text
            analyze_btn = True

ex_cols2 = st.columns(4)
examples2 = [
    ("❤️ Love",     "I love you so much, you mean everything to me."),
    ("😌 Relief",   "Thank goodness that exam is over. I can finally breathe again."),
    ("😂 Fun",      "That prank was hilarious, I haven't laughed this hard in years!"),
    ("😲 Surprise", "I had no idea they were planning a party for me. Totally shocked!"),
]
for i, (label, text) in enumerate(examples2):
    with ex_cols2[i]:
        if st.button(label, key=f"ex2_{i}", use_container_width=True):
            user_input = text
            analyze_btn = True

# ── Analysis & Results ────────────────────────────────────────────────────────
if analyze_btn and user_input.strip():
    with st.spinner("🔄 Analyzing emotions..."):
        time.sleep(0.35)
        results = predict_emotion(user_input.strip())

    dominant   = max(results, key=results.get)
    confidence = results[dominant]
    meta       = EMOTION_META.get(dominant, {"emoji": "❓", "color": "#667eea"})

    st.session_state.history.insert(0, {
        "text":       user_input.strip()[:80] + ("..." if len(user_input) > 80 else ""),
        "dominant":   dominant,
        "confidence": confidence,
        "all":        results,
    })
    st.session_state.total_analyzed += 1

    st.markdown("---")
    st.markdown("## 📊 Results")

    res_col1, res_col2 = st.columns([1, 2])

    # ── Left: Dominant Emotion Card ───────────────────────────────────────
    with res_col1:
        st.markdown(f"""
        <div class='emotion-card'>
            <div class='dominant-emotion'>{meta['emoji']}</div>
            <div class='emotion-label'>{dominant.capitalize()}</div>
            <div class='confidence-text'>Confidence: <b>{confidence*100:.1f}%</b></div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown(f"**Confidence:** {confidence*100:.1f}%")
        st.progress(float(confidence))

        with st.expander("🧹 Preprocessed Text"):
            st.code(clean_text(user_input), language="text")

    # ── Right: Chart ──────────────────────────────────────────────────────
    with res_col2:
        if show_all_emotions:
            df = pd.DataFrame({
                "Emotion": [e.capitalize() for e in results],
                "Score":   [round(v * 100, 2) for v in results.values()],
                "Color":   [EMOTION_META.get(e, {}).get("color", "#667eea") for e in results],
            }).sort_values("Score", ascending=False).head(top_n)

            color_map = dict(zip(df["Emotion"], df["Color"]))

            if chart_type == "Bar Chart":
                fig = px.bar(
                    df, x="Emotion", y="Score",
                    color="Emotion",
                    color_discrete_map=color_map,
                    text="Score",
                    labels={"Score": "Confidence (%)"},
                    title=f"Top {top_n} Emotions",
                )
                fig.update_traces(texttemplate="%{text:.1f}%", textposition="outside")
                fig.update_layout(
                    plot_bgcolor="rgba(0,0,0,0)",
                    paper_bgcolor="rgba(0,0,0,0)",
                    font_color="#ffffff",
                    showlegend=False,
                    margin=dict(t=40, b=20),
                    yaxis=dict(range=[0, 105]),
                    title_font_color="#e2e8f0",
                )

            elif chart_type == "Radar Chart":
                fig = go.Figure(go.Scatterpolar(
                    r=df["Score"].tolist() + [df["Score"].iloc[0]],
                    theta=df["Emotion"].tolist() + [df["Emotion"].iloc[0]],
                    fill="toself",
                    line_color="#667eea",
                    fillcolor="rgba(102,126,234,0.3)",
                ))
                fig.update_layout(
                    polar=dict(
                        bgcolor="rgba(0,0,0,0)",
                        radialaxis=dict(visible=True, range=[0, 100], color="#a0aec0"),
                        angularaxis=dict(color="#ffffff"),
                    ),
                    paper_bgcolor="rgba(0,0,0,0)",
                    font_color="#ffffff",
                    margin=dict(t=30, b=20),
                )

            else:  # Pie Chart
                fig = px.pie(
                    df, names="Emotion", values="Score",
                    color="Emotion",
                    color_discrete_map=color_map,
                    hole=0.4,
                    title=f"Emotion Distribution (Top {top_n})",
                )
                fig.update_layout(
                    paper_bgcolor="rgba(0,0,0,0)",
                    font_color="#ffffff",
                    margin=dict(t=40, b=20),
                    title_font_color="#e2e8f0",
                )

            st.plotly_chart(fig, use_container_width=True)

        # ── All scores table ──────────────────────────────────────────────
        with st.expander("📋 All 11 Emotion Scores"):
            full_df = pd.DataFrame({
                "Emotion":    [f"{EMOTION_META.get(e,{}).get('emoji','❓')} {e.capitalize()}" for e in results],
                "Confidence": [f"{v*100:.2f}%" for v in results.values()],
                "Raw Score":  [round(v, 4) for v in results.values()],
            }).sort_values("Raw Score", ascending=False).drop(columns="Raw Score")
            st.dataframe(full_df, use_container_width=True, hide_index=True)

elif analyze_btn and not user_input.strip():
    st.warning("⚠️ Please enter some text before analyzing.")

# ── History Section ───────────────────────────────────────────────────────────
if st.session_state.history:
    st.markdown("---")
    st.markdown("## 🕓 Analysis History")

    for item in st.session_state.history[:10]:
        em    = item["dominant"]
        emoji = EMOTION_META.get(em, {}).get("emoji", "❓")
        st.markdown(f"""
        <div class='history-item'>
            <b>{emoji} {em.capitalize()}</b>
            ({item['confidence']*100:.1f}%) &nbsp;|&nbsp;
            <span style='color:#a0aec0;'>{item['text']}</span>
        </div>
        """, unsafe_allow_html=True)