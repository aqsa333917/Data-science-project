# 🎭 Emotion Detection System from Text

## 📌 Overview
This project is a **Machine Learning-based Emotion Detection System** that predicts human emotions from text input using Natural Language Processing (NLP).

It classifies text into emotions such as:
- Happiness 😊  
- Sadness 😢  
- Anger 😡  
- Surprise 😲  
- Neutral 😐  
- And more...

---

## 🚀 Features
- Text preprocessing (cleaning, normalization)
- TF-IDF feature extraction (NLP technique)
- Label encoding for emotion classes
- Logistic Regression classifier
- Real-time user input prediction
- Model saving using Pickle
- Easy to extend for web apps (Streamlit/Flask)

---

## 📂 Dataset
- File: `final_dataset.csv`
- Columns:
  - `text` → Input sentence
  - `emotion` → Emotion label

- Dataset Size: ~106,000 records

---

## 🧠 Machine Learning Pipeline

The system follows these steps:

1. Load dataset  
2. Clean text (remove punctuation, numbers, etc.)  
3. Encode labels into numbers  
4. Split data into training and testing sets  
5. Convert text into vectors using TF-IDF  
6. Train Logistic Regression model  
7. Evaluate accuracy  
8. Save model, vectorizer, and encoder  
9. Predict emotion from user input  

---

